import React, { useEffect, useState } from "react";
import axios from "axios";

const API = "http://localhost:3001";

function Dashboard() {
  const [data, setData] = useState([]);
  const token = localStorage.getItem("token");

  useEffect(() => {
    axios.get(`${API}/pemesanan`, {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(res => setData(res.data))
    .catch(() => {
      localStorage.removeItem("token");
      window.location.href = "/";
    });
  }, []);

  return (
    <div style={{ padding:20 }}>
      <h2>Dashboard</h2>
      <ul>
        {data.map(item => (
          <li key={item.id_pemesanan}>
            {item.lokasi_jemput} → {item.lokasi_tujuan}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Dashboard;
