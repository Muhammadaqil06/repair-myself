import React, { useState } from "react";
import axios from "axios";

const API = "http://localhost:3001";

function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [form, setForm] = useState({ nama:"", email:"", password:"", no_hp:"" });

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    const url = isLogin ? `${API}/login` : `${API}/register`;

    try {
      const res = await axios.post(url, form);

      if (isLogin) {
        localStorage.setItem("token", res.data.token);
        window.location.href = "/dashboard";
      } else {
        alert("Register berhasil");
        setIsLogin(true);
      }
    } catch (err) {
      alert("Error");
    }
  };

  return (
    <div style={{ padding:20 }}>
      <h2>{isLogin ? "Login" : "Register"}</h2>
      <form onSubmit={handleSubmit}>
        {!isLogin && <>
          <input name="nama" placeholder="Nama" onChange={handleChange}/>
          <input name="no_hp" placeholder="No HP" onChange={handleChange}/>
        </>}
        <input name="email" placeholder="Email" onChange={handleChange}/>
        <input type="password" name="password" placeholder="Password" onChange={handleChange}/>
        <button type="submit">{isLogin ? "Login" : "Register"}</button>
      </form>
      <p onClick={()=>setIsLogin(!isLogin)}>
        {isLogin ? "Belum punya akun?" : "Sudah punya akun?"}
      </p>
    </div>
  );
}

export default Auth;
