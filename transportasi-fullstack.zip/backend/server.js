const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(express.json());

const SECRET_KEY = process.env.SECRET_KEY || "rahasia123";

const db = mysql.createConnection({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "transportasi_db"
});

function verifyToken(req, res, next) {
  const token = req.headers["authorization"]?.split(" ")[1];
  if (!token) return res.sendStatus(403);

  jwt.verify(token, SECRET_KEY, (err, decoded) => {
    if (err) return res.sendStatus(401);
    req.user = decoded;
    next();
  });
}

app.post("/register", async (req, res) => {
  const { nama, email, password, no_hp } = req.body;
  const hash = await bcrypt.hash(password, 10);

  db.query(
    "INSERT INTO users (nama,email,password,no_hp) VALUES (?,?,?,?)",
    [nama, email, hash, no_hp],
    (err) => {
      if (err) return res.send(err);
      res.json({ message: "Register berhasil" });
    }
  );
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;

  db.query("SELECT * FROM users WHERE email=?", [email], async (err, result) => {
    if (err) return res.send(err);
    if (result.length === 0) return res.json({ message: "User tidak ada" });

    const user = result[0];
    const match = await bcrypt.compare(password, user.password);

    if (!match) return res.json({ message: "Password salah" });

    const token = jwt.sign({ id: user.id_user }, SECRET_KEY, { expiresIn: "1h" });

    res.json({ token });
  });
});

app.get("/pemesanan", verifyToken, (req, res) => {
  db.query("SELECT * FROM pemesanan", (err, result) => {
    if (err) return res.send(err);
    res.json(result);
  });
});

app.listen(process.env.PORT || 3001, () => console.log("Server jalan"));
