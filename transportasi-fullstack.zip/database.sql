CREATE DATABASE transportasi_db;
USE transportasi_db;

CREATE TABLE users (
  id_user INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  password VARCHAR(255),
  no_hp VARCHAR(20)
);

CREATE TABLE pemesanan (
  id_pemesanan INT AUTO_INCREMENT PRIMARY KEY,
  lokasi_jemput VARCHAR(100),
  lokasi_tujuan VARCHAR(100)
);
